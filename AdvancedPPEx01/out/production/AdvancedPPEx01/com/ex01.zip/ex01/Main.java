package com.ex01;

public class Main {
    private static int[] numbers = new int[]{3239, 2479, 1079, 1643};
    public static void main(String[] args) {
        System.out.println("----Threading Solution----");
        ThreadingSolution();
        System.out.println("----Non Threading Solution----");
        NonThreadingSolution();
    }

    private static void ThreadingSolution(){
        ManagerThread[] Threads = new ManagerThread[4];
        long start = System.nanoTime();
        for(int i=0;i<4;i++){
            Threads[i] = new ManagerThread(numbers[i]);
        }
        for(ManagerThread thread : Threads)
            thread.start();
        for(ManagerThread thread : Threads){
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        long elapsedTime = (System.nanoTime()) - start;
        System.out.println(elapsedTime / 1e6 + " ms");
    }

    private static void NonThreadingSolution(){

        SecurityManager sm = new SecurityManager();
        for(int i : numbers){
            long start = System.nanoTime();
            sm.findNumbers(i);
            long elapsedTime = (System.nanoTime()) - start;
            System.out.println(elapsedTime / 1e6 + " ms");
        }

    }


}
