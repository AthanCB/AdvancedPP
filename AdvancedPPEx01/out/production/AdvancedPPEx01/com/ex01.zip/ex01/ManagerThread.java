package com.ex01;

public class ManagerThread extends Thread {
    private int number;
    ManagerThread(int number){
        this.number = number;
    }
    public void run(){
        long start = System.nanoTime();
        SecurityManager sm = new SecurityManager();
        sm.findNumbers(number);
        long elapsedTime = (System.nanoTime()) - start;
        System.out.println(elapsedTime / 1e6 + " ms");
    }
}
