package com.ex01;

public class SecurityManager {
    public SecurityManager(){

    }

    public void findNumbers(int productNumber){
        boolean found = false;
        int counter = 2;
        do{
           if(productNumber%counter==0){
               System.out.println("First number: " + productNumber/counter + ", Second Number: " + counter);
               found = true;
           }
           counter++;
       }while(!found);
    }
}
